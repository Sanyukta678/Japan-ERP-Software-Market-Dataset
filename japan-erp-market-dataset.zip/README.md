# Japan ERP Software Market — Structured Dataset

This repository contains a structured dataset based on publicly available information from the **Japan ERP Software Market** report by NextMSC.

## 📁 Dataset Contents
- `market_overview.csv`
- `segmentation.csv`
- `metadata.json`
- `README.md`

## 📊 Data Description

### 1. Market Overview
Includes:
- Market Size (2024, 2025, 2030)
- CAGR (2025–2030)

### 2. Market Segmentation
Segments include:
- Component (Software, Services)
- Deployment Mode (Cloud, On-Premise)
- Enterprise Size (SMEs, Large Enterprises)
- Industry Verticals (Manufacturing, Retail, BFSI, Government, Healthcare, Others)

## 📚 Source
https://www.nextmsc.com/report/japan-erp-software-market-ic3613

## ⚠️ Disclaimer
This dataset is structured manually for research and educational use only.
